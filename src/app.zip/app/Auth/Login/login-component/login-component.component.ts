import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {AuthService} from '../../auth-service.service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',  // Ensure this matches the actual file name
  styleUrls: ['./login-component.component.css'],
  standalone: true
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  onLogin() {
    this.authService.login(this.username, this.password).subscribe({
      next: (response) => {
        this.authService.saveToken(response.token);
        this.router.navigate(['/home']);
      },
      error: () => alert("Invalid credentials")
    });
  }
}
