import { Component } from '@angular/core';
import { AuthService } from '../../auth-service.service';

@Component({
  selector: 'app-register-component',
  templateUrl: './register-component.component.html',  // Ensure this matches the actual file name
  styleUrls: ['./register-component.component.css'],
  standalone: true
})
export class RegisterComponent {
  username: string = '';
  password: string = '';
  passwordConfirmation: string = '';

  constructor(private authService: AuthService) {}

  onRegister() {
    if (this.password !== this.passwordConfirmation) {
      alert("Passwords do not match");
      return;
    }
    this.authService.register(this.username, this.password, this.passwordConfirmation).subscribe({
      next: () => alert("Registration successful"),
      error: () => alert("Registration failed")
    });
  }
}
