export interface JwtResponse {
  token: string; // Add any other properties returned by the backend
}
