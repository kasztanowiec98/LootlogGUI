import {Routes, RouterModule, provideRouter} from '@angular/router';
import { NgModule } from '@angular/core';

// Import your components
import { LoginComponent } from './auth/login/login-component/login-component.component';
import { RegisterComponent } from './auth/register/register-component/register-component.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' }, // Default route
  { path: '**', redirectTo: '/login' } // Wildcard route to handle unknown paths
];

export const appRoutingProviders = [
  provideRouter(routes)
];
